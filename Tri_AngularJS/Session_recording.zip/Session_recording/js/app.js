angular.module('ngCribs', ['ui.bootstrap']);
